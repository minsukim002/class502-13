package MyDogTest;

public class Q4 {
    public static void main(String[] args) {
        Mydog dog = new Mydog("진돗개", "멍멍이");
        System.out.println(dog.toString());

    }
}
