package coffetest;

public class Menu {
    public static final int StarAmericano = 4000;


    public static final int BeanLatte = 4500;
}
